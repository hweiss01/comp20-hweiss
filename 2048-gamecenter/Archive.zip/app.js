
/**
 * Module dependencies.
 */
var express = require('express');
var routes = require('./routes');
var user = require('./routes/user');
var http = require('http');
var path = require('path');



var app = express();

var mongoUri = process.env.MONGOLAB_URI ||
  process.env.MONGOHQ_URL ||
  'mongodb://localhost/local';

var mongo = require('mongodb');
var db = mongo.Db.connect(mongoUri, function (error, databaseConnection) {
    db = databaseConnection;
  });



// all environments
app.set('port', process.env.PORT || 3000);
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'jade');
app.use(express.favicon());
app.use(express.logger('dev'));
app.use(express.json());
app.use(express.bodyParser());
app.use(express.urlencoded());
app.use(express.methodOverride());
//app.use(allowCrossDomain);
app.use(app.router);
app.use(express.static(path.join(__dirname, 'public')));

// development only
if ('development' == app.get('env')) {
  app.use(express.errorHandler());
}

  app.all('*', function(req, res, next) {
  res.header("Access-Control-Allow-Origin", "*");
  res.header("Access-Control-Allow-Headers", "X-Requested-With");
  next();
 });

app.get('/', function(req, res){
  res.set('Content-Type', 'text/html');
    var indexPage;
    mongo.Db.connect(mongoUri, function(err, db){
      db.collection('scores', function(er, collection){
        collection.find().sort({score:-1}).limit(100).toArray(function(err, cursor) {
          if (!err) {
            indexPage += "<!DOCTYPE HTML><html><head><title>2048 Game Center</title></head><body><h1>2048 Game Center</h1><table><tr><th>User</th><th>Score</th><th>Timestamp</th></tr>";

            for (var count = 0; count < cursor.length; count++) {
              indexPage += "<tr><td>" + cursor[count].username + "</td><td>" + cursor[count].score + "</td><td>" + cursor[count].created_at + "</td></tr>";
            }
            indexPage+= "</table></body></html>";
            res.send(indexPage);
          }
          else {
          res.send(500);
          }
        });
      });
    });
});
/*
app.get('/drop', function(req, res) {
  mongo.Db.connect(mongoUri, function (err, db) {
    db.collection("scores", function(error, collection){
      collection.drop();
      res.send(200);
    });
  });
});

*/
app.get('/scores.json', function(req, res, next){
 // res.header("Access-Control-Allow-Origin", "*");
 // res.header("Access-Control-Allow-Headers", "X-Requested-With");
  mongo.Db.connect(mongoUri, function (err, db){
    db.collection('scores', function(er, collection){
      var user = req.query.username;
    collection.find({username:user}).sort({score:-1}).limit(100).toArray(function(err, cursor) {

       if (cursor.length == 0) { res.send('[]'); }
       var scores = '[';

        for (var count = 0; count < (cursor.length)-1; count++) {
          scores = scores + '{"username":"' + cursor[count].username + '", "score":' + cursor[count].score + ', grid":"' + cursor[count].grid + '", "created_at":"' + cursor[count].created_at + '", "_id":"' + cursor[count]._id + '"},';
        }     

        scores = scores + '{"username":"' + cursor[count].username + '", "score":' + cursor[count].score + ', grid":"' + cursor[count].grid + '", "created_at":"' + cursor[count].created_at + '", "_id":"' + cursor[count]._id + '"}]'
        res.send(scores);
      });
  });
  });
});

app.post('/submit.json', function(req,res, next){
 // res.header("Access-Control-Allow-Origin", "*");
  //res.header("Access-Control-Allow-Headers", "X-Requested-With");
  mongo.Db.connect(mongoUri, function(err, db){
    db.collection("scores", function (er, collection){
      var username = req.body.username;
      var score = req.body.score;
      var grid = req.body.grid;
      console.log(grid);
      
      if (username === undefined || score===undefined || grid===undefined) { res.send(500)};
      var created_at = new Date(year, month, day, hours, minutes, seconds, milliseconds);
      var theDocument = {"username":username, "score":score, "grid":grid, "created_at":created_at}; 
      
      collection.insert(theDocument, function(err, saved){});
      res.send(200);
    });
  });
});


http.createServer(app).listen(app.get('port'), function(){
  console.log('Express server listening on port ' + app.get('port'));
});



